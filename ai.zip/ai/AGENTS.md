---

# Memory Compaction Rules

The `/ai` directory must remain compact so agents can load repository context quickly.

Different memory layers are compacted differently.

## Core Memory (`ai/core/*`)
Core memory represents durable repository truths.

Rules:
- Keep files concise and focused.
- Replace outdated sections instead of appending history.
- Avoid storing chronological logs inside core files.
- Never automatically delete core files.

Examples of core files:
- agent-invariants.md
- repo-purpose.md
- module-index.md
- readme-alignment.md
- runbook.md
- documentation-index.md

---

## State Memory (`ai/state/*`)
State files represent the latest working session.

Rules:
- Rewrite these files rather than appending indefinitely.
- Remove outdated context once it is captured in core files or logs.
- Keep files short and easy to scan.

Guidelines:
- `current-state.md` should remain concise and reflect only the latest verified state.
- `handoff.md` should contain only the next actionable context.

---

## Index Memory (`ai/indexes/*`)
Index files describe the current repository structure.

Rules:
- Regenerate indexes instead of accumulating history.
- Remove entries for deleted or moved files.
- Index files should represent the **current repository state only**.

---

## Log Memory (`ai/log/*`)
Logs are append-only during normal operation.

Rules:
- Log significant events such as repository scans, memory updates, and major discoveries.
- Avoid logging trivial actions.

If logs grow too large:
- summarize older entries
- move summaries into `ai/archive/`
- keep recent events in `events.jsonl`

---

## Archive Storage (`ai/archive/*`)
Archived files contain historical summaries.

Rules:
- Archived content is not part of the normal load order.
- Archive older logs, obsolete task notes, or large historical analyses.
- Archive files should contain summaries rather than raw logs.

---

## Compaction Triggers

Agents should compact memory when:

- state files become difficult to scan
- index files contain stale entries
- documentation indexes contain removed files
- log files grow large enough to reduce usefulness

---

## Compaction Method

When compacting memory:

1. preserve current repository truth
2. summarize historical context
3. archive low-value historical details
4. remove duplicate or stale entries
5. keep files optimized for fast future loading