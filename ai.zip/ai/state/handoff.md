# Handoff

Load these first on the next session:
- `ai/state/current-state.md`
- `ai/core/readme-alignment.md`
- `ai/core/repo-purpose.md`
- `ai/core/runbook.md`
- `TODO.md` when touching performance or materialization work

Area-specific follow-up files:
- Fluent execution: `src/main/java/laughing/man/commits/builder/FilterQueryBuilder.java`, `src/main/java/laughing/man/commits/filter/FilterImpl.java`, `src/main/java/laughing/man/commits/filter/FilterExecutionPlan.java`, `src/main/java/laughing/man/commits/util/ReflectionUtil.java`
- SQL-like: `src/main/java/laughing/man/commits/sqllike/SqlLikeQuery.java`, `src/main/java/laughing/man/commits/sqllike/parser/SqlLikeParser.java`, `src/main/java/laughing/man/commits/sqllike/internal/validation/SqlLikeValidator.java`, `docs/sql-like.md`
- Charts/reports: `src/main/java/laughing/man/commits/chart/*`, `src/main/java/laughing/man/commits/report/ReportDefinition.java`, `docs/charts.md`, `docs/reports.md`
- Snapshot/testing utilities: `src/main/java/laughing/man/commits/snapshot/*`, `src/main/java/laughing/man/commits/testing/*`

Open questions worth resolving next:
- Should the documentation examples be updated down to `1.0.0`, or is `pom.xml` meant to move up to `1.3.0`?
- Should `MIGRATION.md` and `RELEASE.md` be corrected to document limited subquery support and chained SQL-like joins?
- Is the remaining WP5 fallback acceptable, or should selective materialization expand further?

Update discipline:
- Re-run `mvn -B -ntp test` after behavior changes.
- Re-run the doc consistency script after doc changes, but do not assume it catches version drift or stale limitation notes.
