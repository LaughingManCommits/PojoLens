# Current State

As of 2026-03-12:

- Verified: `mvn -B -ntp test` passed locally with `398` tests and no failures.
- Verified: `scripts/check-doc-consistency.ps1` passed locally when run with Windows PowerShell.
- Verified: The repository currently behaves like a healthy library codebase with strong contract-test coverage.
- Verified: The active planned work is concentrated in `TODO.md`.

## Main Open Items

- Verified from `TODO.md`: WP5 selective/lazy materialization is still the main unfinished engine redesign area.
- Verified from `TODO.md`: next work should decide whether computed-field-plus-join flows keep the safe full-materialization fallback or receive more optimization.
- Verified from `TODO.md`: benchmark follow-up is still needed before calling the remaining WP5 slice done.

## Current Documentation Risks

- Mismatch: benchmark jar/tag examples use `1.3.0` while `pom.xml` says `1.0.0`.
- Mismatch: `MIGRATION.md` and `RELEASE.md` still describe SQL-like subqueries and multi-join plans as unsupported, but code/tests support limited subqueries and chained joins.
- Verified: the existing doc-check script does not detect those drifts.

## Not Verified In This Bootstrap Run

- Unknown locally: lint profile results
- Unknown locally: SpotBugs results
- Unknown locally: benchmark threshold status
