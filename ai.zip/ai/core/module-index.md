# Module Index

## Top-Level Structure

- Verified: `.github/workflows` contains one CI workflow, `ci.yml`.
- Verified: `docs/` holds product and process reference docs.
- Verified: `src/main/java/laughing/man/commits` is the single source root for the library.
- Verified: `src/test/java/laughing/man/commits` and `src/test/resources/fixtures` hold contract tests and fixtures.
- Verified: `benchmarks/` stores benchmark threshold configs.
- Verified: `scripts/` stores validation helpers and benchmark suite arg files.
- Verified: `target/` exists as generated build output and is not a source-of-truth directory.

## Main Package Inventory

- Verified: `sqllike` (`35` files): SQL-like public API, AST, parser, binder, validation, execution, lint, explain, cache.
- Verified: `benchmark` (`22` files): JMH suites, metric loaders/exporters, threshold/parity checkers, plot generation.
- Verified: `filter` (`14` files): execution engine, joins, ordering, grouping, aggregation, execution-plan cache.
- Verified: `chart` (`12` files): chart models, presets, mapping, validation.
- Verified: `builder` (`8` files): fluent query builder, selectors, rules, metrics, time buckets.
- Verified: `telemetry` (`4` files): stage event contract and helpers.
- Verified: `util` (`4` files): reflection/materialization, value conversion, string/time helpers.
- Verified: `computed`, `snapshot`, `table`, and `testing` provide focused feature layers on top of the core pipeline.
- Verified: `time` (`1` file) holds `TimeBucketPreset`.
- Verified: `report` (`1` file) holds `ReportDefinition`.

## High-Signal Files

- Verified: `src/main/java/laughing/man/commits/PojoLens.java` is the main facade.
- Verified: `src/main/java/laughing/man/commits/builder/FilterQueryBuilder.java` is the fluent configuration hub.
- Verified: `src/main/java/laughing/man/commits/filter/FilterImpl.java` is the core execution hub.
- Verified: `src/main/java/laughing/man/commits/sqllike/SqlLikeQuery.java` is the SQL-like public contract.
- Verified: `src/main/java/laughing/man/commits/util/ReflectionUtil.java` is the main schema/materialization utility.
- Verified: `src/test/java/laughing/man/commits/PublicApiCoverageTest.java` and `src/test/java/laughing/man/commits/PublicSurfaceContractTest.java` anchor public API expectations.
